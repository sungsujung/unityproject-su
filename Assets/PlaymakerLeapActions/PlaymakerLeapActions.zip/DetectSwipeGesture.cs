﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

/**
 * PlayMaker custom action
 */
namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LeapMotion Actions")]
	[Tooltip("Allows you to detect the Swipe gesture from the LeapMotion sensor.")]
	
	public class DetectSwipeGesture : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the gesture progress.")]
		public FsmFloat progress;
		
		[Tooltip("Custom event to be sent on swipe detection.")]
		public FsmEvent swipeLeftDetectedEvent;
		public FsmEvent swipeRightDetectedEvent;
		public FsmEvent swipeDownDetectedEvent;
		public FsmEvent swipeUpDetectedEvent;
		public FsmEvent swipeBackDetectedEvent;
		public FsmEvent swipeFrontDetectedEvent;
		
		
		private LeapManager manager;
		
		
		// called when the state becomes active
		public override void OnEnter()
		{
			progress.Value = 0f;
			checkGestureStatus();
		}
		
		// called before leaving the current state
		public override void OnExit ()
		{
		}
		
		public override void OnUpdate()
		{
			checkGestureStatus();
		}
		
		private void checkGestureStatus()
		{		
			if(manager == null)
			{
				manager = LeapManager.Instance;
			}
			
			if(manager != null && manager.IsLeapInitialized() && manager.IsPointableValid())
			{
				if(manager.IsGestureSwipeDetected())
				{
					progress.Value = 1f;
					
					switch(manager.GetSwipeDirection())
					{
						case LeapManager.SwipeDirection.Left:
							Fsm.Event(swipeLeftDetectedEvent);
							break;

						case LeapManager.SwipeDirection.Right:
							Fsm.Event(swipeRightDetectedEvent);
							break;

						case LeapManager.SwipeDirection.Down:
							Fsm.Event(swipeDownDetectedEvent);
							break;

						case LeapManager.SwipeDirection.Up:
							Fsm.Event(swipeUpDetectedEvent);
							break;

						case LeapManager.SwipeDirection.Back:
							Fsm.Event(swipeBackDetectedEvent);
							break;

						case LeapManager.SwipeDirection.Front:
							Fsm.Event(swipeFrontDetectedEvent);
							break;
					}
				}
				else
				{
					progress.Value = 0.5f; //manager.GetGestureProgress(userId, gesture);
				}
			
			}
		}
	}
}