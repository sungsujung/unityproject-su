﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LeapMotion Actions")]
	[Tooltip("Allows you to get the pointable data (position, direction and rotation) from the LeapMotion sensor.")]
	
	public class GetPointableData : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the flag, if the pointable data is valid or not.")]
		public FsmBool isValid;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the position of the pointable.")]
		public FsmVector3 position;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the direction of the pointable.")]
		public FsmVector3 direction;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the rotation of the pointable.")]
		public FsmQuaternion rotation;
		
		private LeapManager manager;
		
		
		// called when the state becomes active
		public override void OnEnter()
		{			
			getPointableData();
		}
		
		// called before leaving the current state
		public override void OnExit ()
		{
		}
		
		public override void OnUpdate()
		{
			getPointableData();			
		}
		
		// Update is called once per frame
		private void getPointableData()
		{		
			if(manager == null)
			{
				manager = LeapManager.Instance;
			}
			
			if(manager != null && manager.IsLeapInitialized() && manager.IsPointableValid())
			{
				isValid.Value = true;
				
				position.Value = manager.GetPointablePos();
				direction.Value = manager.GetPointableDir();
				rotation.Value = manager.GetPointableQuat();
			}
			else
			{
				isValid.Value = false;
			}
		}
	}
}