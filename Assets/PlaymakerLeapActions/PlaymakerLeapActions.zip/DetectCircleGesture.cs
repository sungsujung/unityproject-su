﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

/**
 * PlayMaker custom action
 */
namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LeapMotion Actions")]
	[Tooltip("Allows you to detect the Circle gesture from the LeapMotion sensor.")]
	
	public class DetectCircleGesture : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the gesture progress.")]
		public FsmFloat progress;
		
		[Tooltip("Custom event to be sent on circle detection.")]
		public FsmEvent circleDetectedEvent;
		
		
		private LeapManager manager;
		
		
		// called when the state becomes active
		public override void OnEnter()
		{
			progress.Value = 0f;
			checkGestureStatus();
		}
		
		// called before leaving the current state
		public override void OnExit ()
		{
		}
		
		public override void OnUpdate()
		{
			checkGestureStatus();
		}
		
		private void checkGestureStatus()
		{		
			if(manager == null)
			{
				manager = LeapManager.Instance;
			}
			
			if(manager != null && manager.IsLeapInitialized() && manager.IsPointableValid())
			{
				if(manager.IsGestureCircleDetected())
				{
					progress.Value = 1f;
					Fsm.Event(circleDetectedEvent);
				}
				else
				{
					progress.Value = manager.GetGestureCircleProgress();
				}
			
			}
		}
	}
}