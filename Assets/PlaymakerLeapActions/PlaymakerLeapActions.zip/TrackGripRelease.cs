﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

/**
 * PlayMaker custom action
 */
namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LeapMotion Actions")]
	[Tooltip("Allows you to track hand cursor, grips and releases, recognized by the LeapMotion sensor.")]
	
	public class TrackGripRelease : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the normalized cursor position.")]
		public FsmVector3 cursorNormalizedPos;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the cursor position on screen, in pixels.")]
		public FsmVector3 cursorScreenPos;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the selected game object, if anything gets selected by the Grip.")]
		public FsmGameObject selectedGameObj;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the selection point, if a game object gets selected by the Grip.")]
		public FsmVector3 selectionPoint;
		
		[Tooltip("Custom event to be sent on grip detection.")]
		public FsmEvent gripDetectedEvent;
		
		[Tooltip("Custom event to be sent on release detection.")]
		public FsmEvent releaseDetectedEvent;
		
		
		private LeapManager manager;
		private bool bGripDetected;
		private float fDetectionStartTime;
		
		// called when the state becomes active
		public override void OnEnter()
		{			
			cursorNormalizedPos.Value = Vector3.zero;
			cursorScreenPos.Value = Vector3.zero;
			
			bGripDetected = false;
			fDetectionStartTime = Time.realtimeSinceStartup + 1f;
		}
		
		public override void OnExit ()
		{
			if(bGripDetected)
			{
				bGripDetected = false;
				Fsm.Event(releaseDetectedEvent);
			}
		}
		
		public override void OnUpdate()
		{
			if(Time.realtimeSinceStartup >= fDetectionStartTime)
			{
				checkInteractionStatus();			
			}
		}
		
		private void checkInteractionStatus()
		{		
			if(manager == null)
			{
				manager = LeapManager.Instance;
			}
		
			if(manager != null && manager.IsLeapInitialized())
			{
				if(manager.IsHandValid())
				{
					cursorNormalizedPos.Value = manager.GetCursorNormalizedPos();
					cursorScreenPos.Value = manager.GetCursorScreenPos();
					
					if(!bGripDetected && manager.IsHandGripDetected())
					{
						bGripDetected = true;
						Fsm.Event(gripDetectedEvent);
					}
					
					if(bGripDetected && manager.IsHandReleaseDetected())
					{
						bGripDetected = false;
						selectedGameObj.Value = null;
						
						Fsm.Event(releaseDetectedEvent);
					}
				}
				else
				{
					if(bGripDetected)
					{
						bGripDetected = false;
						Fsm.Event(releaseDetectedEvent);
					}
				}
				
				if(bGripDetected)
				{
					RaycastHit hit;
					Ray ray = Camera.mainCamera.ScreenPointToRay(cursorScreenPos.Value);
					//Debug.DrawRay(ray.origin, ray.direction);
					
					if(Physics.Raycast(ray, out hit))
					{
						selectedGameObj.Value = hit.collider.gameObject;
						selectionPoint.Value = hit.point;
					}
				}
				
			}
		}
	}
}